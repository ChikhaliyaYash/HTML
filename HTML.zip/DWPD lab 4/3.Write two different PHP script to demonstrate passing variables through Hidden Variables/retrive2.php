<?php
 if(isset($_POST['submit']))
 {
  $fn=$_POST['fname'];
  $ln=$_POST['lname'];

  echo "First name = $fn <br>";
  echo "last name = $ln";
 }
?>
 
