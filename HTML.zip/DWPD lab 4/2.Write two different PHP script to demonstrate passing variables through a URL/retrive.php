<?php
 echo "First Name : ".$_GET['First_name']."<br>";
 echo "Last Name : ".$_GET['last_name'];
?>
