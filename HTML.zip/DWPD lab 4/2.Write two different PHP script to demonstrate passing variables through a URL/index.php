<?php
 $fname="Kalyan";
 $lname="Polytechnic";
?>
<a href="retrive.php?First_name=<?php echo $fname; ?>&last_name=<?php echo $lname; ?>">
Click here to Pass Variable through URL
</a>
