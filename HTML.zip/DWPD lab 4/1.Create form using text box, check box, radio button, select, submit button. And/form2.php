<html>
<head><title>Form Data</title></head>
<body>

  <?php
  echo "name:";
  $name=$_GET["txt_name"];
  echo " $name"." </br>";
  echo "Username::";
  $uname=$_GET["txt_uname"];
  echo "$uname"." </br>";
  echo "Password::";
  $pwd=$_GET["pwd"];
  echo "$pwd"." </br>";
  echo "hobby:";
  if(isset($_GET['check_list']))
  {if(!empty($_GET['check_list']))
    {foreach($_GET['check_list'] as $selected)
      {echo $selected."</br>";}
    }
  }
  echo "city:";
  $city=$_GET["dd_city"];
  echo "$city"." </br>";
  echo "gender:";
  echo $_GET['rb']."</br>";
  echo "Phone no:"; $Phoneno=$_GET["txt_phone"];
  echo "$Phoneno"." </br>";
  echo "Email:";
  $email=$_GET["txt_mail"];
  echo "$email"." </br>";
  ?>
</body>
</html>
