<html>
<head>
<title>Hidden Variables</title>
</head>
<body>
 <form method="post" action="retrive2.php">
  <input type="hidden" name="fname" value="Yash">
  <input type="hidden" name="lname" value="Chikhaliya">
  <input type="submit" name="submit" value="submit">
 </form>
</body>
</html>
