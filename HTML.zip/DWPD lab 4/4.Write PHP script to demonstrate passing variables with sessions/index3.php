<html>
<head>
<title>Session Demo</title>
</head>
<form method="post" action="retrive3.php">
 Enter Your name : <input type="text" name="fname">
 <input type="submit" name="submit" value="Create session">
</form>
</html>
